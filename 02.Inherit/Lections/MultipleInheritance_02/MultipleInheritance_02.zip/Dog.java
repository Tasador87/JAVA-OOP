package Lections.MultipleInheritance_02;

public class Dog extends Animal {
    public void bark(){
        System.out.println("barking...");
    }
}
