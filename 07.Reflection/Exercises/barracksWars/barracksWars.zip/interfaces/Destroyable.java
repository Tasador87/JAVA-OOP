package Exercises.barracksWars.interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
