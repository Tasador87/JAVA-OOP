package Exercises.barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
