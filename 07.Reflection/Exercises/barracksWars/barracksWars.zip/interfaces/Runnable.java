package Exercises.barracksWars.interfaces;

public interface Runnable {
	void run();
}
