package Exercises.barracksWars.core.factories;

import Exercises.barracksWars.interfaces.Unit;
import Exercises.barracksWars.interfaces.UnitFactory;
import Exercises.barracksWars.models.units.*;
import jdk.jshell.spi.ExecutionControl;

public class UnitFactoryImpl implements UnitFactory {

	private static final String UNITS_PACKAGE_NAME = "Exercises.barracksWars.models.units.";

	@Override
	public Unit createUnit(String unitType) throws ExecutionControl.NotImplementedException {

		Unit unit = null;

		if (unitType.equals(Archer.class.getSimpleName())){
			unit = new Archer();
		}else if (unitType.equals(Pikeman.class.getSimpleName())){
			unit = new Pikeman();
		}else if (unitType.equals(Swordsman.class.getSimpleName())){
			unit = new Swordsman();
		}else if (unitType.equals(Horseman.class.getSimpleName())){
			unit = new Horseman();
		}else if (unitType.equals(Gunner.class.getSimpleName())){
			unit = new Gunner();
		}
		return unit;
	}
}
