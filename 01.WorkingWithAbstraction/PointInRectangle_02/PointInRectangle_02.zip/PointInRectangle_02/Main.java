package Lections.PointInRectangle_02;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int[] points = Arrays.stream(reader.readLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();

        Point pointX = new Point(points[0],points[1]);
        Point pointY = new Point(points[2],points[3]);
        Rectangle rectangle = new Rectangle(pointX,pointY);

        int lines = Integer.parseInt(reader.readLine());

        while (lines > 0){

            int[] somePoints = Arrays.stream(reader.readLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();
            Point newPoint = new Point(somePoints[0],somePoints[1]);
            System.out.println(rectangle.contains(newPoint));
            lines--;
        }
    }
}