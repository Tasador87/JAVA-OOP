package Lections.PointInRectangle_02;

public class Point {
    private int cordinateX;
    private int cordinateY;


    public Point(int cordinateX, int cordinateY) {
        this.cordinateX = cordinateX;
        this.cordinateY = cordinateY;
    }

    public int getCordinateX() {
        return cordinateX;
    }

    public int getCordinateY() {
        return cordinateY;
    }
}
