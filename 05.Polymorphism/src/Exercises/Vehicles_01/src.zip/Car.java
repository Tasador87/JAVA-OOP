import java.text.DecimalFormat;

public class Car extends Vehicle {

    public Car(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }

    @Override
    public void drive(double distance) {
        if (distance * (getFuelConsumption() + 0.9) <= getFuelQuantity()) {
            double result = getFuelQuantity() - (distance * (getFuelConsumption() + 0.9));
            super.setFuelQuantity(result);
            DecimalFormat format = new DecimalFormat("0.##");
            System.out.println("Car travelled " + format.format(distance) + " km");
        }else {
            System.out.println("Car needs refueling");
        }
    }

    @Override
    public void refuel(double liters) {
        super.setFuelQuantity(getFuelQuantity() + liters);
    }

}