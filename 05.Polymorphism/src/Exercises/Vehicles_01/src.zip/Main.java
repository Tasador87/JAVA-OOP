import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] carData = scanner.nextLine().split("\\s+");  // "Car {fuel quantity} {liters per km}"
        double carFuelQuantity = Double.parseDouble(carData[1]);
        double carFuelConsumption = Double.parseDouble(carData[2]);

        String[] truckData = scanner.nextLine().split("\\s+"); // "Truck {fuel quantity} {liters per km}"
        double truckFuelQuantity = Double.parseDouble(truckData[1]);
        double truckFuelConsumption = Double.parseDouble(truckData[2]);

        Vehicle car = new Car(carFuelQuantity, carFuelConsumption);
        Vehicle truck = new Truck(truckFuelQuantity, truckFuelConsumption);

        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < n; i++) {

            String[] data = scanner.nextLine().split("\\s+");

            if (data[1].equals("Car")) {
                if (data[0].equals("Drive")) {
                    car.drive(Double.parseDouble(data[2]));
                } else if (data[0].equals("Refuel")) {
                    car.refuel(Double.parseDouble(data[2]));
                }
            } else if (data[1].equals("Truck")) {
                if (data[0].equals("Drive")) {
                    truck.drive(Double.parseDouble(data[2]));
                } else if (data[0].equals("Refuel")) {
                    truck.refuel(Double.parseDouble(data[2]));
                }
            }
        }
        System.out.println(String.format("Car: %.2f",car.getFuelQuantity()));
        System.out.println(String.format("Truck: %.2f",truck.getFuelQuantity()));
    }
}
