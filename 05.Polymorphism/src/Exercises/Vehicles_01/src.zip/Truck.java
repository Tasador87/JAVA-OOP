import java.text.DecimalFormat;

public class Truck extends Vehicle {

    public Truck(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }

    @Override
    public void drive(double distance) {
        if (distance * (getFuelConsumption() + 1.6) <= getFuelQuantity()) {
            double result = getFuelQuantity() - (distance * (getFuelConsumption() + 1.6));
            super.setFuelQuantity(result);
            DecimalFormat format = new DecimalFormat("0.##");
            System.out.println("Truck travelled " + format.format(distance) + " km");
        }else {
            System.out.println("Truck needs refueling");
        }
    }

    @Override
    public void refuel(double liters) {
        super.setFuelQuantity(getFuelQuantity() + (liters * 0.95));
    }
}
