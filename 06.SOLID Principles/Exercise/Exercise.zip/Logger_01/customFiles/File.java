package Exercise.Logger_01.customFiles;

public interface File {
    void write();
    int getSize();
    void appendBuffer(String text);
}
