public interface Rentable extends Car {
    Integer minRentDay();
    Double pricePerDay();
}
