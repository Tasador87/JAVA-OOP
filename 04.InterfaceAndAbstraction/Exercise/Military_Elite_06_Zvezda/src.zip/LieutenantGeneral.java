public interface LieutenantGeneral {
    void addPrivate(Private soldier);
}