public interface Repair {
    String getName();
    int getHoursWorked();
}
