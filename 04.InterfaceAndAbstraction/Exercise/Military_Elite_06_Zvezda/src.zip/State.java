public enum State {
    inProgress,
    Finished;
}
