public interface Mission {
    void completeMission();
    String getCodeName();
    State getState();
}