public interface SpecialisedSoldier {

    Corps getCorps();
}
